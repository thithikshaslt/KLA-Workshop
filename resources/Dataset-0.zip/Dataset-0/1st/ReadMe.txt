Input1 : Contain Care Area information

unit: Micrometre/micron     1x10^-6 m
Care Area Size= 100.0 micron

Care Area Column Details:
1st column : ID (must be unique)
2nd Column : Xmin
3rd Column : Xmax
4th Column : Ymin
5th Column : Ymax

Main Field Column Details:
1st column : ID (must be unique)
2nd Column : Xmin
3rd Column : Xmax
4th Column : Ymin
5th Column : Ymax

Sub Field Column Details:
1st column : ID (must be unique)
2nd Column : Xmin
3rd Column : Xmax
4th Column : Ymin
5th Column : Ymax
6th Column : Main Field ID


